<?php
class ProductController {
	public function actionProduct() {
		return true;
	}
}
