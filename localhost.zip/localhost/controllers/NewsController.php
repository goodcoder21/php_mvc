<?php 
class NewsController {
	public function actionIndex () {
		echo 'you run news controller';
		return true;
	}
}