<?php
return array(
	'news' => 'news/index',
	'products' => 'products/list',
);
