<?php 
return array (
	'host' => 'localhost',
	'dbname' => 'mvc',
	'user' => 'root',
	'password' => '',
);